from odoo import fields, models, _

import logging

from secrets import token_hex
from requests import post
from MqttLibPy.client import MqttClient

from ..utils import get_company
from ..service.routes import Routes
import re
_logger = logging.getLogger(__name__)


class Module(models.Model):
    _inherit = "ir.module.module"
    
    def get_company(self):
        company_id = self.env['res.company'].search([("company_name", "!=", "")], limit=1)
        if not company_id:
            company_id = self.env['res.company'].search([], limit=1)

        return company_id

    def button_immediate_upgrade(self):
        company = self.get_company()
        uuid = company.company_name
        # rfc = re.sub(r'\D', '', company.partner_id.vat)
        rfc = company.partner_id.vat
        country = company.partner_id.country_id.code.lower()
        xml_json = [{'key': 'test'}]
        url = f"uuid/{uuid}/rfc/{rfc}/country/{country}/timeout_client"
        print(f"RUTA {company.key}")
        mqtt_client = MqttClient("api.xmarts.com", 1883, prefix=f"uuid/{uuid}/rfc/{rfc}/country/{country}/", encryption_key=company.key)
        mqtt_client.send_message_serialized(
            [xml_json],
            f"uuid/{uuid}/rfc/{rfc}/country/{country}/timeout_client", 
            valid_json=True, 
            secure=True
        )
        res = super(Module, self).button_immediate_upgrade()
        return res
    
    def button_immediate_install(self):
        company = self.get_company()
        uuid = company.company_name
        # rfc = re.sub(r'\D', '', company.partner_id.vat)
        rfc = company.partner_id.vat
        country = company.partner_id.country_id.code.lower()
        xml_json = [{'key': 'test'}]
        url = f"uuid/{uuid}/rfc/{rfc}/country/{country}/timeout_client"
        print(f"RUTA {company.key}")
        mqtt_client = MqttClient("api.xmarts.com", 1883, prefix=f"uuid/{uuid}/rfc/{rfc}/country/{country}/", encryption_key=company.key)
        mqtt_client.send_message_serialized(
            [xml_json],
            f"uuid/{uuid}/rfc/{rfc}/country/{country}/timeout_client", 
            valid_json=True, 
            secure=True
        )
        res = super(Module, self).button_immediate_install()
        return res

    def button_immediate_uninstall(self):
        company = self.get_company()
        uuid = company.company_name
        # rfc = re.sub(r'\D', '', company.partner_id.vat)
        rfc = company.partner_id.vat
        country = company.partner_id.country_id.code.lower()
        xml_json = [{'key': 'test'}]
        url = f"uuid/{uuid}/rfc/{rfc}/country/{country}/timeout_client"
        print(f"RUTA {company.key}")
        mqtt_client = MqttClient("api.xmarts.com", 1883, prefix=f"uuid/{uuid}/rfc/{rfc}/country/{country}/", encryption_key=company.key)
        mqtt_client.send_message_serialized(
            [xml_json],
            f"uuid/{uuid}/rfc/{rfc}/country/{country}/timeout_client", 
            valid_json=True, 
            secure=True
        )
        res = super(Module, self).button_immediate_uninstall()
        return res

class AccountMove(models.Model):
    _inherit = 'account.move'

    master_server = 'api.xmarts.com'

    xml_mtx = fields.Binary()

    def master_callback(self):
        logger = logging.getLogger("Xma core")

        # Esto devuelve companias random, puede haber problemas si la instancia de oodo tiene varias companias
        company_id = get_company(self.env)

        self.ensure_logged_in(company_id)
        company_name = company_id.company_name

        axo_chat_module = self.env['ir.module.module'].search([("name", "=", "axo_chat")], limit=1)
        is_axo_chat_installed = axo_chat_module.state == 'installed'

        logger.info(f"Axo chat module is {'active' if is_axo_chat_installed  else 'inactive'}")

        # logger.info(f"{company_id.company_name}, {company_id.password}, {company_id.key}")

        mqtt_client = MqttClient(self.master_server, 1883,
                                 prefix=f"uuid/{company_name}/",
                                 encryption_key=company_id.key,
                                 uuid=company_id.company_name, qos=1, client_id=company_name)

        Routes(mqtt_client, self.env, company_id, f'rfc/+/country/+/')
        if is_axo_chat_installed:
            self.env['project.task'].init_axo_chat(mqtt_client)

        mqtt_client.listen()

    def ensure_logged_in(self, company_id):
        _logger.info("ensure_logged_in" + str(company_id))
        if not company_id.key:
            password = token_hex(20)
            response = post(f"https://{self.master_server}/register", json={'company': company_id.name, 'password': password})
            json_response = response.json()
            _logger.info("json_response" + str(json_response))
            company_id.write({"company_name": json_response['company'],
                              "password": json_response['password'], "key": json_response['key']})
            self.env.cr.commit()
