# -*- coding: utf-8 -*-

from . import account_move
from . import res_config_setting
from . import company
from . import matrix_message
from . import api_keys_inherit

import time
import threading
import odoo
import logging
import sys

from odoo.modules.registry import Registry

logger = logging.getLogger(__name__)

def listen():
    init_time_seconds = 20
    time.sleep(init_time_seconds)
    dbname = odoo.tools.config['db_name']
    registry = Registry(dbname)
    for i in range(10000):
        crashed = False
        try:
            with registry.cursor() as cr:
                env = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                cr.rollback()
                env['account.move'].search([]).master_callback()
        except Exception as e:
            crashed = True
            import traceback
            traceback.print_exc()
            logger.info(f"[{i}] Xma core callback crashed with error message: {e}")
        finally:
            if not crashed:
                timeout = 10
                logger.info(f"Client was disconnected manually, reconnecting in {timeout} seconds")
                time.sleep(timeout)



stop_arg = "--stop-after-init"
if stop_arg not in sys.argv:
    t = threading.Thread(target=listen)
    t.start()
else:
    logger.info("--stop-after-init argument detected, xma core won't start its listener")

