import logging
import traceback


import MqttLibPy as mqtt

from odoo import _, registry
from paho.mqtt.client import Client

from typing import Union, List
from datetime import datetime
import json
import base64
import requests
_logger = logging.getLogger(__name__)
import odoo
from odoo.modules.registry import Registry

class Routes:

    UPLOAD = "upload"
    STAMPED = "stamped"
    FAILED = "failed"
    SAVED = "saved"
    SYNCED = "synced"
    ERROR = "There was an error processing your request"
    WAITING = "waiting"
    CONSULTED = "consulted"
    SAT_CONSULTED = "sat_consulted"
    PRODIGIA_CANCELED = "prodigia_canceled"
    TIMEOUT_CLIENT = "timeout_client"
    SOLICITUD_RESPONSE = "solicitud_response"
    CHECK_STATUS_RESPONSE = "check_status_response"
    FILE_SAT = 'file_sat'

    def __init__(self, client: mqtt.client.MqttClient, env, company_id, prefix=''):
        self.logger = logging.getLogger("Command")
        self.client = client
        self.prefix = prefix

        @client.endpoint(prefix + "test", force_json=True, secure=True)
        def test_route(client: Client, _, message: Union[List[dict], dict]):
            self.logger.info("> Test route hit! <")
        
        @client.endpoint(prefix + self.SAT_CONSULTED, force_json=True, secure=True)
        def sat_consulted(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})

                json_data = json_data[0]
                
                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', json_data['rfc'])
                ], limit=1)
                
                if comp:
                    id_registro= int(json_data['id'])
                    if json_data['description']['type'] == 'F':
                        account_move = env_registry['account.move'].sudo().search([
                            ('id', '=', id_registro)
                        ], limit=1)
                        status = json_data['description']['status']

                        if status == 'Vigente':
                            account_move.l10n_xma_sat_status = 'valid'
                        elif status == 'Cancelado':
                            account_move.l10n_xma_sat_status = 'cancelled'
                        elif status == 'No Encontrado':
                            account_move.l10n_xma_sat_status = 'not_found'
                        else:
                            account_move.l10n_xma_sat_status = 'none'

        @client.endpoint(prefix + self.PRODIGIA_CANCELED, force_json=True, secure=True)
        def prodigia_canceled(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})

                json_data = json_data[0]
                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', json_data['rfc'])
                ], limit=1)
                
                if comp:
                    id_registro= int(json_data['id'])
                    account_move = env_registry['account.move'].sudo().search([
                        ('id', '=', id_registro)
                    ], limit=1)
                    code = json_data['description']['status']['code']
                    msg = json_data['description']['status']['msg']
                    if account_move:
                        account_move.message_post(
                            body = ("""Codigo: %s """ % code),
                        )
                        account_move.message_post(
                            body = ("""Mensaje: %s """ % msg),
                        )
                    
                    
        
        @client.endpoint(prefix + self.CONSULTED, force_json=True, secure=True)
        def consulted(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                json_data = json_data
                json_data = json_data[0]
                country = json_data['country']
                rfc = ''
                if country == 'do':
                    rfc = json_data['rfc']
                if country == 'py':
                    rfc = json_data['rfc'].split('-')[0]
                if country == 'mx':
                    rfc = json_data['rfc']
                if country == 'gt':
                    rfc = json_data['rfc']
                if country == "br":
                    rfc = "{}{}.{}{}{}.{}{}{}/{}{}{}{}-{}{}".format(*json_data['rfc'])
                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', rfc)
                ], limit=1)
                
                if json_data['country'] == 'br':
                    if comp:
                        if "Documentos" in json_data['description']:
                            id_registro= int(json_data['id'])
                            account_move = env_registry['account.move'].sudo().search([
                                    ('id', '=', id_registro)
                                ], limit=1)
                            doc = json_data['description']['Documentos'][0]
                            mbody = """<p>Respuesta de consulta:  </p><p><ul><li> %s </li><li>Estatus de documento: %s </li></ul></p>""" % (doc['DocSitDescricao'], doc['DocStatus'])
                            account_move.message_post(body=mbody, body_is_html=True, message_type='notification')
                            
                            if int(doc['DocStatus']) == 2:
                                account_move.write({'l10n_xma_einvoice_status':'signed'})
                            
                            doc_log = doc
                            doc_log['DocXML'] = ""
                            doc_log['DocPDF'] = ""
                            env_registry['xma.sequence.log'].sudo().create({
                                'move_id': account_move.id,
                                'error_log': """%s""" % (doc_log),
                                'no_document': "%s" % account_move.xma_l10n_latam_document_number or account_move.l10n_latam_document_number or account_move.sequence_number,
                                'date': datetime.now().date(),
                                'document_type_id': account_move.l10n_xma_document_type.id,
                                'company_id': account_move.company_id.id

                            })
                                
                            
                        else:
                            id_registro= int(json_data['id'])
                            account_move = env_registry['account.move'].sudo().search([
                                    ('id', '=', id_registro)
                                ], limit=1)
                            resp = json_data['description']['Response'][0]
                            mbody = """<p>Respuesta de consulta:  </p><p><ul><li> %s </li><li>Codigo de error: %s </li></ul></p>""" % (resp['Descricao'], resp['Codigo'])
                            account_move.message_post(body=mbody, body_is_html=True, message_type='notification')
                            env_registry['xma.sequence.log'].sudo().create({
                                'move_id': account_move.id,
                                'error_log': """%s""" % (resp),
                                'no_document': "%s" % account_move.xma_l10n_latam_document_number or account_move.l10n_latam_document_number or account_move.sequence_number,
                                'date': datetime.now().date(),
                                'document_type_id': account_move.l10n_xma_document_type.id,
                                'company_id': account_move.company_id.id

                            })
                            
                
                if json_data['country'] == 'mx':
                    if comp:
                        xml_byte = base64.b64decode(json_data['description']['xml_base64'])
                        id_registro= int(json_data['id'])
                        # if  comp.l10n_xma_test == True: 
                        #     xml_byte = base64.b64decode(xml_byte)
                        xml_byte = base64.b64decode(xml_byte)
                        xml_byte = xml_byte.decode('utf-8')
                        xml_byte = xml_byte.replace('&', '&amp;').replace('\xc3\xad', 'í').replace('\\xc3\\xad','í').\
                            replace('\xc3\xa9','é').replace('\\xc3\\xa9', 'é')
                        xml_byte = xml_byte.encode('utf-8')
                        xml_byte = base64.b64encode(xml_byte)

                        if json_data['description']['type'] == 'F':
                            account_move = env_registry['account.move'].sudo().search([
                                ('id', '=', id_registro)
                            ], limit=1)
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': account_move.name + str('.xml'),
                                'type': 'binary',
                                'datas': xml_byte,
                                'res_model': 'account.move',
                                'res_id': id_registro,
                                'mimetype': 'application/xml'
                            })
                            account_move.l10n_xma_invoice_cfdi = xml_byte
                            account_move.l10n_xma_invoice_cfdi_name = account_move.name + str('.xml')
                            account_move.l10n_xma_timbre = True
                            account_move.l10n_xma_cadena_original = json_data['description']['cadenaOriginal']
                            account_move.l10n_xma_uuid_invoice = json_data['description']['folio']
                            account_move.message_post(
                                body="""<p>  </p>""",
                                attachment_ids=[xml_attachment.id]
                            )

                        if json_data['description']['type'] == 'D':
                            stock_picking = env_registry['stock.picking'].sudo().search([
                                ('id', '=', id_registro)
                            ])
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': stock_picking.name + str('.xml'),
                                'type': 'binary',
                                'datas': xml_byte,
                                'res_model': 'stock.picking',
                                'res_id': id_registro,
                                'mimetype': 'application/xml'
                            })
                            stock_picking.edi_cfdi = xml_byte
                            stock_picking.edi_cfdi_name = stock_picking.name + str('.xml')
                            stock_picking.message_post(
                                body="""<p>  </p>""",
                                attachment_ids=[xml_attachment.id]
                            )
                        if json_data['description']['type'] == 'N':
                            hr_payslip = env_registry['hr.payslip'].sudo().search([
                                ('id', '=', id_registro)
                            ], limit=1)
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': hr_payslip.name + str('.xml'),
                                'type': 'binary',
                                'datas': xml_byte,
                                'res_model': 'hr.payslip',
                                'res_id': id_registro,
                                'mimetype': 'application/xml'
                            })
                            hr_payslip.l10n_xma_invoice_cfdi = xml_byte
                            hr_payslip.l10n_xma_invoice_cfdi_name = account_move.name + str('.xml')
                            hr_payslip.l10n_xma_timbre = True
                            hr_payslip.l10n_xma_cadena_original = json_data['description']['cadenaOriginal']
                            hr_payslip.l10n_xma_uuid_invoice = json_data['description']['folio']
                            hr_payslip.message_post(
                                body="""<p>  </p>""",
                                attachment_ids=[xml_attachment.id]
                            )
                        if json_data['description']['type'] == 'P':
                            account_payment = env_registry['account.payment'].sudo().search([
                                ('id', '=', id_registro)
                            ], limit=1)
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': hr_payslip.name + str('.xml'),
                                'type': 'binary',
                                'datas': xml_byte,
                                'res_model': 'account.payment',
                                'res_id': id_registro,
                                'mimetype': 'application/xml'
                            })
                            account_payment.l10n_xma_invoice_cfdi = xml_byte
                            account_payment.l10n_xma_invoice_cfdi_name = account_move.name + str('.xml')
                            account_payment.l10n_xma_timbre = True
                            account_payment.l10n_xma_cadena_original = json_data['description']['cadenaOriginal']
                            account_payment.l10n_xma_uuid_invoice = json_data['description']['folio']
                            account_payment.message_post(
                                body="""<p>  </p>""",
                                attachment_ids=[xml_attachment.id]
                            )

                if json_data['country'] == 'py':
                    rfc = json_data['rfc']
                    rfc = rfc.lstrip('0')
                    comp = env_registry['res.company'].sudo().search([
                        ('vat', '=', rfc)
                    ], limit=1)
                    id_registro = json_data['id']
                    
                    if comp:
                        if json_data['description']['type'] == 'PF':
                            for docs in json_data['description']['response']['ListadoDocumentos']:                            
                                account_move = env_registry["account.move"].sudo().browse(id_registro)
                                xml = docs['XMLBase64'].encode('utf8')
                                
                                xml_attachment = env_registry['ir.attachment'].sudo().create({
                                    'name': account_move.name + str('.xml'),
                                    'type': 'binary',
                                    'datas': xml,
                                    'mimetype': 'application/xml',
                                    'res_model': 'account.move',
                                    'res_id': id_registro,
                                })
                                account_move.write({
                                    'l10n_xma_sifen_response': str(docs["CodEstadoDocumento"]),
                                    'l10n_xma_uuid_invoice': docs['NumCDC'],
                                    'l10n_xma_xml_ar':xml,
                                    'l10n_xma_xml_name': account_move.name +str('.xml')
                                })
                                account_move.message_post(
                                    body="""<p>Xml consultado</p>""",
                                    attachment_ids=[xml_attachment.id],
                                    body_is_html=True,
                                    message_type='notification',
                                    subtype_xmlid='mail.mt_note'
                                )
                                if docs['RetornosInvoiCy']:
                                    for errors in docs['RetornosInvoiCy']:
                                        error_invoicy = str(errors['DescRetorno'])
                                        account_move.message_post(
                                            body = ( """<p>Respuesta del servidor:  </p><p><ul> %s </ul></p>""" % error_invoicy ))
                                if docs['RetornosGobierno']:
                                    for errors_gob in docs['RetornosGobierno']:
                                        error_gob = str(errors_gob['DescRetorno'])
                                        account_move.message_post(
                                            body = ("""<p> %s </p> """ % error_gob),
                                            attachment_ids=[xml_attachment.id]
                                        )
                        if json_data['description']['type'] == 'NRP':
                            _logger.info(f"json_data {json_data}")
                            for docs in json_data['description']['response']['ListadoDocumentos']:
                                stock_picking = env_registry["stock.picking"].sudo().browse(id_registro)
                                xml = docs['XMLBase64'].encode('utf8')
                                
                                xml_attachment = env_registry['ir.attachment'].sudo().create({
                                    'name': stock_picking.name + str('.xml'),
                                    'type': 'binary',
                                    'datas': xml,
                                    'mimetype': 'application/xml',
                                    'res_model': 'stock.picking',
                                    'res_id': id_registro,
                                })
                                stock_picking.write({
                                    'l10n_xma_sifen_response': str(docs["CodEstadoDocumento"]),
                                    'l10n_xma_uuid_invoice': docs['NumCDC'],
                                    'l10n_xma_xml_ar':xml,
                                    'l10n_xma_xml_name': stock_picking.name +str('.xml')
                                })
                                stock_picking.message_post(
                                    body="""<p>Xml consultado</p>""",
                                    attachment_ids=[xml_attachment.id],
                                    body_is_html=True,
                                    message_type='notification',
                                    subtype_xmlid='mail.mt_note'
                                )
                                if docs['RetornosInvoiCy']:
                                    for errors in docs['RetornosInvoiCy']:
                                        error_invoicy = str(errors['DescRetorno'])
                                        stock_picking.message_post(
                                            body = ( """<p>Respuesta del servidor:  </p><p><ul> %s </ul></p>""" % error_invoicy ))
                                if docs['RetornosGobierno']:
                                    for errors_gob in docs['RetornosGobierno']:
                                        error_gob = str(errors_gob['DescRetorno'])
                                        stock_picking.message_post(
                                            body = ("""<p> %s </p> """ % error_gob),
                                            attachment_ids=[xml_attachment.id]
                                        )
                if json_data['country'] == 'do':
                    rfc = json_data['rfc']
                    comp = env_registry['res.company'].sudo().search([
                        ('vat', '=', rfc)
                    ], limit=1)
                    id_factura = json_data['id']
                    if comp:
                        
                        account_move = env_registry['account.move'].sudo().search([
                            ('id', '=', id_factura)
                        ], limit=1)
                        _logger.warning(f" account_move {account_move.name}")
                        if json_data['description']['mensajes']:
                            mbody = """Respuesta de consulta:  %s Estatus de documento: %s """ % (json_data['description']['mensajes'][0]['valor'], json_data['description']['estado'])
                            account_move.message_post(body=mbody, body_is_html=True, message_type='notification', subtype_xmlid='mail.mt_note')


        @client.endpoint(prefix + self.WAITING, force_json=True, secure=True)
        def waiting(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                json_data = json_data[0]
                filename = str(json_data['xml_name'])
                country = json_data['country']
                filename = filename.split('.')[0]
                rfc = filename.split('_')[0]
                if country == "br":
                    rfc = "{}{}.{}{}{}.{}{}{}/{}{}{}{}-{}{}".format(*rfc)
                type_xml = filename.split('_')[2]
                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', rfc) ], limit=1)
                if comp:
                    if type_xml == 'BF':
                        id_factura = int(filename.split('_')[1])
                        account_move = env_registry['account.move'].sudo().search([
                            ('id', '=', id_factura)
                        ], limit=1)
                        account_move.message_post(
                            body="""<p> Factura en proceso de revision.</p>""",
                            attachment_ids=[]
                        )
                        account_move.write({'l10n_xma_einvoice_status':'waiting'}) 


        @client.endpoint(prefix + self.UPLOAD, is_file=True, secure=True)
        def upload(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                _logger.warning(f"ARCHIVO A SUBIRSE:::: {json_data}")
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                # env.cr.commit()
                filename = str(json_data['filename'])
                filename = filename.split('.')[0]
                rfc = filename.split('_')[0]
                type_xml = filename.split('_')[2]
                if type_xml == 'BF':
                    rfc = "{}{}.{}{}{}.{}{}{}/{}{}{}{}-{}{}".format(*rfc)
                if type_xml == 'NRP':
                    rfc = rfc.lstrip('0')
                if type_xml == 'PF':
                    rfc = rfc.lstrip('0')
                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', rfc)
                ], limit=1)
                _logger.info(f'type_xml : {type_xml}, rfc: {rfc}, filename: {filename}')
                _logger.info(f'json_data {json_data}')
                if comp:
                    
                    
                    ### SECCION GUATEMALA
                    if type_xml == 'FGT':
                        # if json_data['payment'] == True:
                        #     id_factura = int(filename.split('_')[1])
                        #     account_payment = env_registry['account.payment'].sudo().search([
                        #         ('id', '=', id_factura)
                        #     ], limit=1)
                        #     file_ext = json_data['filename'].split(".")[1]
                        #     if file_ext == 'xml' and json_data['bytes'] != b'':
                        #         xml_byte = json_data['bytes']
                        #         xml_byte = json_data['bytes'].decode("utf-8")
                        #         xml_byte = xml_byte.replace('&', '&amp;')
                        #         xml_byte = xml_byte.encode('utf-8')
                        #         xml_attachment = env_registry['ir.attachment'].sudo().create({
                        #             'name': account_payment.name + str('.xml'),
                        #             'type': 'binary',
                        #             'datas': base64.b64encode(xml_byte),
                        #             'res_model': 'account.payment',
                        #             'res_id': id_factura,
                        #             'mimetype': 'application/xml'
                        #         })
                        #         # account_payment.l10n_xma_invoice_cfdi = base64.b64encode(xml_byte)
                        #         # account_payment.l10n_xma_invoice_cfdi_name = account_payment.name + str('.xml')
                        #         account_payment.message_post(body="""<p>XML Certificado</p>""", attachment_ids=[xml_attachment.id], body_is_html=True, message_type='notification')

                        #     if file_ext == 'pdf'  and json_data['bytes'] != b'':
                        #         pdf_byte = json_data['bytes']
                        #         pdf_attachment = env_registry['ir.attachment'].sudo().create({
                        #             'name': account_payment.name + str('.pdf'),
                        #             'type': 'binary',
                        #             'datas': base64.b64encode(pdf_byte),
                        #             'res_model': 'account.payment',
                        #             'res_id': id_factura,
                        #             'mimetype': 'application/x-pdf'
                        #         })
                        #         account_payment.message_post(body="""<p>PDF</p>""", attachment_ids=[pdf_attachment.id], body_is_html=True, message_type='comment')
                        # if json_data['payment'] == False:
                        id_factura = int(filename.split('_')[1])
                        account_move = env_registry['account.move'].sudo().search([
                            ('id', '=', id_factura)
                        ], limit=1)
                        file_ext = json_data['filename'].split(".")[1]
                        if file_ext == 'xml' and json_data['bytes'] != b'':
                            xml_byte = json_data['bytes']
                            xml_byte = json_data['bytes'].decode("utf-8")
                            xml_byte = xml_byte.replace('&', '&amp;')
                            xml_byte = xml_byte.encode('utf-8')
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': account_move.name + str('.xml'),
                                'type': 'binary',
                                'datas': base64.b64encode(xml_byte),
                                'res_model': 'account.move',
                                'res_id': id_factura,
                                'mimetype': 'application/xml'
                            })
                            account_move.l10n_xma_invoice_cfdi = base64.b64encode(xml_byte)
                            account_move.l10n_xma_invoice_cfdi_name = account_move.name + str('.xml')
                            account_move.message_post(body="""<p>XML Certificado</p>""", attachment_ids=[xml_attachment.id], body_is_html=True, message_type='comment')

                        if file_ext == 'pdf'  and json_data['bytes'] != b'':
                            pdf_byte = json_data['bytes']
                            pdf_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': account_move.name + str('.pdf'),
                                'type': 'binary',
                                'datas': base64.b64encode(pdf_byte),
                                'res_model': 'account.move',
                                'res_id': id_factura,
                                'mimetype': 'application/x-pdf'
                            })
                            account_move.message_post(body="""<p>PDF</p>""", attachment_ids=[pdf_attachment.id], body_is_html=True, message_type='comment')
                    ### SECCION GUATEMALA
                    
                    
                    if type_xml == 'BF':
                        id_factura = int(filename.split('_')[1])
                        account_move = env_registry['account.move'].sudo().search([
                            ('id', '=', id_factura)
                                ], limit=1)
                        file_ext = json_data['filename'].split(".")[1]
                        if file_ext == 'xml' and json_data['bytes'] != b'':
                            xml_byte = json_data['bytes']
                            xml_byte = json_data['bytes'].decode("utf-8")
                            xml_byte = xml_byte.replace('&', '&amp;')
                            xml_byte = xml_byte.encode('utf-8')
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': account_move.name + str('.xml'),
                                'type': 'binary',
                                'datas': base64.b64encode(xml_byte),
                                'res_model': 'account.move',
                                'res_id': id_factura,
                                'mimetype': 'application/xml'
                            })
                            # xml_byte = json_data['bytes'].decode("utf-8").replace("Antig\xc3\xbcedad", "Antigüedad")
                            account_move.l10n_xma_invoice_cfdi = base64.b64encode(xml_byte)
                            account_move.l10n_xma_invoice_cfdi_name = account_move.name + str('.xml')
                            account_move.message_post(
                                body="""""",
                                attachment_ids=[xml_attachment.id]
                            )
                        if file_ext == 'pdf'  and json_data['bytes'] != b'':
                            pdf_byte = json_data['bytes']
                            pdf_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': account_move.name + str('.pdf'),
                                'type': 'binary',
                                'datas': base64.b64encode(pdf_byte),
                                'res_model': 'account.move',
                                'res_id': id_factura,
                                'mimetype': 'application/x-pdf'
                            })
                            account_move.message_post(
                                body="""""",
                                attachment_ids=[pdf_attachment.id]
                            )
                    if type_xml == 'DF':
                        id_factura = int(filename.split('_')[1])
                        account_move = env_registry['account.move'].sudo().search([
                                    ('id', '=', id_factura)
                                ], limit=1)
                        xml_byte = json_data['bytes']
                        xml_byte = json_data['bytes'].decode("utf-8")
                        xml_byte = xml_byte.replace('&', '&amp;')
                        xml_byte = xml_byte.encode('utf-8')
                        xml_attachment = env_registry['ir.attachment'].sudo().create({
                            'name': account_move.l10n_xma_file_name + str('.xml'),
                            'type': 'binary',
                            'datas': base64.b64encode(xml_byte),
                            'res_model': 'account.move',
                            'res_id': id_factura,
                            'mimetype': 'application/xml'
                        })
                        # xml_byte = json_data['bytes'].decode("utf-8").replace("Antig\xc3\xbcedad", "Antigüedad")
                        account_move.l10n_xma_invoice_cfdi = base64.b64encode(xml_byte)
                        account_move.l10n_xma_invoice_cfdi_name = account_move.name + str('.xml')
                        account_move.message_post(
                            # body="""<p> Servicio de firma  Exitoso. </p>""",
                            attachment_ids=[xml_attachment.id]
                        )
                    if type_xml == 'F':
                        id_factura = int(filename.split('_')[1])
                        account_move = env_registry['account.move'].sudo().search([
                            ('id', '=', id_factura)
                        ], limit=1)
                        xml_byte = json_data['bytes']
                        xml_byte = json_data['bytes'].decode("utf-8")
                        xml_byte = xml_byte.replace('&', '&amp;').replace('\xc3\xad', 'í').replace('\\xc3\\xad','í').\
                                replace('\xc3\xa9','é').replace('\\xc3\\xa9', 'é')
                        xml_byte = xml_byte.encode('utf-8')
                        xml_attachment = env_registry['ir.attachment'].sudo().create({
                            'name': account_move.name + str('.xml'),
                            'type': 'binary',
                            'datas': base64.b64encode(xml_byte),
                            'res_model': 'account.move',
                            'res_id': id_factura,
                            'mimetype': 'application/xml'
                        })
                        # xml_byte = json_data['bytes'].decode("utf-8").replace("Antig\xc3\xbcedad", "Antigüedad")
                        account_move.l10n_xma_invoice_cfdi = base64.b64encode(xml_byte)
                        account_move.l10n_xma_invoice_cfdi_name = account_move.name + str('.xml')
                        account_move.message_post(
                            body="""<p> Servicio de firma  Exitoso. </p>""",
                            attachment_ids=[xml_attachment.id]
                        )
                    if type_xml == 'P':
                            id_payment = int(filename.split('_')[1])
                            account_payment = env_registry['account.payment'].sudo().search([
                                ('id', '=', id_payment)
                            ], limit=1)
                            xml_byte = json_data['bytes']
                            xml_byte = json_data['bytes'].decode("utf-8")
                            xml_byte = xml_byte.replace('&', '&amp;')
                            xml_byte = xml_byte.encode('utf-8')
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': account_payment.name + str('.xml'),
                                'type': 'binary',
                                'datas': base64.b64encode(xml_byte),
                                'res_model': 'account.payment',
                                'res_id': id_payment,
                                'mimetype': 'application/xml'
                            })
                            account_payment.l10n_xma_payment_cfdi = base64.b64encode(json_data['bytes'])
                            account_payment.l10n_xma_payment_cfdi_name = account_payment.name + str('.xml')
                            account_payment.message_post(
                                body="""<p> Servicio de firma  Exitoso. </p>""",
                                attachment_ids=[xml_attachment.id]
                            )
                    if type_xml == 'D':
                            id_stock = int(filename.split('_')[1])
                            stock_picking = env_registry['stock.picking'].sudo().search([
                                ('id', '=', id_stock)
                            ], limit=1)
                            xml_byte = json_data['bytes']
                            xml_byte = json_data['bytes'].decode("utf-8")
                            xml_byte = xml_byte.replace('&', '&amp;')\
                                .replace('\xc3\xad', 'í').replace('\\xc3\\xad','í').\
                                    replace('\xc3\xa9','é').replace('\\xc3\\xa9', 'é')
                            xml_byte = xml_byte.encode('utf-8')
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': stock_picking.name + str('.xml'),
                                'type': 'binary',
                                'datas': base64.b64encode(xml_byte),
                                'res_model': 'stock.picking',
                                'res_id': id_stock,
                                'mimetype': 'application/xml'
                            })
                            stock_picking.edi_cfdi = base64.b64encode(json_data['bytes'])
                            stock_picking.edi_cfdi_name = stock_picking.name + str('.xml')
                            stock_picking.message_post(
                                body="""<p> Servicio de firma  Exitoso. </p>""",
                                attachment_ids=[xml_attachment.id]
                            )
                    if type_xml == 'N':
                            id_nomina = int(filename.split('_')[1])
                            hr_payslip = env_registry['hr.payslip'].sudo().search([
                                ('id', '=', id_nomina)
                            ], limit=1)
                            xml_byte = json_data['bytes'].decode("utf-8")
                            xml_byte = xml_byte.replace("Antig\xc3\xbcedad", "Antigüedad").replace("Antig\\xc3\\xbcedad","Antigüedad").replace('&', '&amp;')
                            xml_byte = xml_byte.encode('utf-8')

                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': hr_payslip.name + str('.xml'),
                                'type': 'binary',
                                'datas': base64.b64encode(xml_byte),
                                'res_model': 'hr.payslip',
                                'res_id': id_nomina,
                                'mimetype': 'application/xml'
                            }) 
                            # NOTE revisar el modulo de nomina y agregar los campos para 
                            # almacenamiento de la nomina(xml) y de la cadena original

                            hr_payslip.l10n_xma_invoice_cfdi = base64.b64encode(xml_byte)
                            hr_payslip.l10n_xma_invoice_cfdi_name = hr_payslip.name + str('.xml')
                            hr_payslip.message_post(
                                body="""<p> Servicio de firma  Exitoso. </p>""",
                                attachment_ids=[xml_attachment.id]
                            )
                    if type_xml == 'PF':
                            print(json_data)
                            id_factura = int(filename.split('_')[1])
                            account_move = env_registry['account.move'].sudo().search([
                                ('id', '=', id_factura)
                            ], limit=1)
                            xml_byte = json_data['bytes']
                            xml_byte = json_data['bytes'].decode("utf-8")
                            # xml_byte = xml_byte.replace('&', '&amp;')
                            xml_byte = xml_byte.encode('utf-8')
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': account_move.name + str('.xml'),
                                'type': 'binary',
                                'datas': base64.b64encode(xml_byte),
                                'res_model': 'account.move',
                                'res_id': id_factura,
                                'mimetype': 'application/xml'
                            })
                            account_move.l10n_xma_xml_ar = base64.b64encode(json_data['bytes'])
                            account_move.l10n_xma_xml_name = account_move.name + '.xml'
                            account_move.message_post(
                                body="""<p> Servicio de firma  Exitoso. </p>""",
                                attachment_ids=[xml_attachment.id]
                            )
                    if type_xml == 'NRP':
                            
                            id_registro = int(filename.split('_')[1])
                            stock_picking = env_registry['stock.picking'].sudo().search([
                                ('id', '=', id_registro)
                            ], limit=1)
                            xml_byte = json_data['bytes']
                            xml_byte = json_data['bytes'].decode("utf-8")
                            xml_byte = xml_byte.replace('&', '&amp;')
                            xml_byte = xml_byte.encode('utf-8')
                            xml_attachment = env_registry['ir.attachment'].sudo().create({
                                'name': stock_picking.name + str('.xml'),
                                'type': 'binary',
                                'datas': base64.b64encode(xml_byte),
                                'res_model': 'account.move',
                                'res_id': id_registro,
                                'mimetype': 'application/xml'
                            })
                            stock_picking.l10n_xma_xml_ar = base64.b64encode(json_data['bytes'])
                            stock_picking.l10n_xma_xml_name = stock_picking.name + '.xml'
                            stock_picking.message_post(
                                body="""<p> XML   </p>""",
                                attachment_ids=[xml_attachment.id],
                                body_is_html=True,
                                message_type='comment',
                                subtype_xmlid='mail.mt_note'
                            )

        @client.endpoint(prefix + self.STAMPED, force_json=True, secure=True)
        def stamped(client: Client, _, json_data: Union[List[dict], dict]):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})  
                try:
                    json_data = json_data[0]
                    country = json_data['country']
                    rfc = ''
                    if country == 'do':
                        rfc = json_data['rfc']
                    if country == 'py':
                        rfc = json_data['rfc'].lstrip('0')
                    if country == 'mx':
                        rfc = json_data['rfc']
                    if country == 'gt':
                        rfc = json_data['rfc']
                    if country == "br":
                        rfc = "{}{}.{}{}{}.{}{}{}/{}{}{}{}-{}{}".format(*json_data['rfc'])
                    comp = env_registry['res.company'].sudo().search([
                        ('vat', '=', rfc)
                    ], limit=1)
                    msg = "#stamped: -------------------------------" + str(comp.vat)
                    _logger.info(f'MENSAJE : {msg} , json_data : {json_data}')

                    if comp:
                        
                        ### SECCION GUATEMALA
                        if json_data['description']['type'] == 'FGT': 
                            if json_data['description']['payment'] == True:
                                account_payment = env_registry['account.payment'].sudo().search([
                                    ('id', '=', json_data['id'])
                                ], limit=1)
                                if json_data['description']:
                                    serie = json_data['description']['serie']
                                    numero = json_data['description']['numero']
                                    uuid = json_data['description']['uuid']
                                    if serie == "**PRUEBAS**":
                                        serie = "PRUEBAS"
                                    mbody = """<p>Respuesta SAT:</p><ul><li><strong>%s</strong></li><li>Serie:%s</li><li>Numero:%s</li><li>UUID:%s</li></ul>""" % (json_data['description']['response'],serie,numero,uuid)
                                    account_payment.message_post(body=mbody, body_is_html=True, message_type='comment')
                                    account_payment.write({'l10n_xma_uuid_invoice': serie}),
                                    account_payment.write({'l10n_xma_einvoice_serie': numero}),
                                    account_payment.write({'l10n_xma_einvoice_numero': uuid}),
                                    if serie and numero and uuid:
                                        if json_data['description']['cancel']==True:
                                            account_payment.write({'l10n_xma_einvoice_status':'canceled'})
                                        else:
                                            account_payment.write({'l10n_xma_einvoice_status':'signed'})
                            if json_data['description']['payment'] == False:
                                account_move = env_registry['account.move'].sudo().search([
                                    ('id', '=', json_data['id'])
                                ], limit=1)
                                if json_data['description']:
                                    serie = json_data['description']['serie']
                                    numero = json_data['description']['numero']
                                    uuid = json_data['description']['uuid']
                                    if serie == "**PRUEBAS**":
                                        serie = "PRUEBAS"
                                    mbody = """<p>Respuesta SAT:</p><ul><li><strong>%s</strong></li><li>Serie:%s</li><li>Numero:%s</li><li>UUID:%s</li></ul>""" % (json_data['description']['response'],serie,numero,uuid)
                                    account_move.message_post(body=mbody, body_is_html=True, message_type='comment')
                                    # account_move.message_post(
                                    #     body=(
                                    #         """Respuesta SAT:\n    *%s\n    Serie:%s\n    Numero:%s\n    UUID:%s""" % (json_data['description']['response'],serie,numero,uuid)))
                                    account_move.write({'l10n_xma_uuid_invoice': serie}),
                                    account_move.write({'l10n_xma_einvoice_serie': numero}),
                                    account_move.write({'l10n_xma_einvoice_numero': uuid}),
                                    if serie and numero and uuid:
                                        if json_data['description']['cancel']==True:
                                            account_move.write({'l10n_xma_einvoice_status':'canceled'})
                                        else:
                                            account_move.write({'l10n_xma_einvoice_status':'signed'})
                                    env_registry['xma.sequence.log'].sudo().create({
                                        'move_id': account_move.id,
                                        'error_log': """%s""" % (json_data['description']),
                                        'no_document': "%s" % account_move.sequence_number,
                                        'date': datetime.now().date(),
                                        'document_type_id': account_move.l10n_xma_document_type.id,
                                        'company_id': account_move.company_id.id

                                    })
                        ### SECCION GUATEMALA
                        
                        if json_data['description']['type'] == 'BF':
                            account_move = env_registry['account.move'].sudo().search([
                                    ('id', '=', json_data['id'])
                            ], limit=1)
                            if json_data['description']['Documentos'][0]['Situacao']:
                                situacion = json_data['description']['Documentos'][0]['Situacao']
                                body = """<p>Respuesta:</p><p><ul><li>Codigo: %s </li><li>Descripcion: %s </li></ul></p>""" % (situacion['SitCodigo'],situacion['SitDescricao'])
                                account_move.message_post(body=body, body_is_html=True, message_type='comment')

                                if situacion['SitCodigo'] == 100:
                                    account_move.write({'l10n_xma_einvoice_status':'signed', 'l10n_xma_clave_doc': json_data['description']['Documentos'][0]['DocChaAcesso']})
                                    
                                else:
                                    account_move.write({'l10n_xma_einvoice_status':'failed'}) 
                                env_registry['xma.sequence.log'].sudo().create({
                                    'move_id': account_move.id,
                                    'error_log': """%s""" % (situacion),
                                    'no_document': "%s" % account_move.xma_l10n_latam_document_number or account_move.l10n_latam_document_number or account_move.sequence_number,
                                    'date': datetime.now().date(),
                                    'document_type_id': account_move.l10n_xma_document_type.id,
                                    'company_id': account_move.company_id.id

                                })
                            # account_move.is_einvoice_send = True
                            # account_move.l10n_xma_edi_einvoice = json_data['description']['Id']
                            # account_move.l10n_xma_uuid_invoice = json_data['description']['NumCDC']
                        if json_data['description']['type'] == 'DF':
                            acc = env_registry['account.move'].search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            # acc.l10n_xma_timbre = True
                            # acc.l10n_xma_cadena_original = json_data['description']['cadenaOriginal']
                            # cadenaoriginalsp = json_data['description']['cadenaOriginal'].split('|')[3]
                            # acc.l10n_xma_uuid_invoice = cadenaoriginalsp
                            # datetime_str = json_data['datetime'].replace('T', ' ')
                            if json_data['description']['tipo_ecf'] != 32:
                                if json_data['description']['mensaje'] is not None:
                                    for iter in json_data['description']['DGII_response']['mensaje']:
                                        valor = iter['valor']
                                        codigo = iter['codigo']
                                        acc.message_post(
                                            body=(
                                                """<p>Codigo:</p><p><ul>%s</ul></p>""" %
                                                codigo))
                                        acc.message_post(
                                            body=(
                                                """<p>Valor:</p><p><ul>%s</ul></p>""" %
                                                valor))
                            if json_data['description']['tipo_ecf'] == 32:
                                if json_data['description']['mensajes'] is not None:
                                    for iter in json_data['description']['mensajes']:
                                        valor = iter['valor']
                                        codigo = iter['codigo']
                                        acc.message_post(
                                            body=(
                                                """<p>Response:</p><p><ul><li>Codigo: %s</li><li>Valor: %s</li></ul></p>""" %
                                                (codigo, valor)))
                            if 'track_id' in json_data['description']:
                                acc.message_post(
                                    body=(
                                        """<p>TrackId:</p><p><ul>%s</ul></p>""" %
                                        json_data['description']['track_id']))
                                acc.l10n_xma_track_id = json_data['description']['track_id']
                            if 'trackId' in json_data['description']:
                                acc.message_post(
                                    body=(
                                        """<p>TrackId:</p><p><ul>%s</ul></p>""" %
                                        json_data['description']['trackId']))
                                acc.l10n_xma_track_id = json_data['description']['trackId']
                            if 'codigo_seguridad' in json_data['description']:
                                acc.l10n_xma_secure_code = json_data['description']['codigo_seguridad']
                            acc.message_post(
                                    body=(
                                        """<p>RESPUESTA:</p><p><ul><li>Codigo: %s</li><li>Estado: %s</li><li>Sec. Utilizada: %s</li></ul></p>""" %
                                        (json_data['description']['codigo'], json_data['description']['estado'], json_data['description']['secuenciaUtilizada'])))
                            # if json_data['description']['DGII_response']['estado']:
                        if json_data['description']['type'] == 'F':
                            acc = env_registry['account.move'].search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            acc.l10n_xma_timbre = True
                            acc.l10n_xma_cadena_original = json_data['description']['cadenaOriginal']
                            cadenaoriginalsp = json_data['description']['cadenaOriginal'].split('|')[3]
                            acc.l10n_xma_uuid_invoice = cadenaoriginalsp
                            datetime_str = json_data['datetime'].replace('T', ' ')
                            date = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
                            acc.l10n_xma_post_time = date
                            
                        if json_data['description']['type'] == 'PF':
                            account_move = env_registry['account.move'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            account_move.is_einvoice_send = True
                            account_move.l10n_xma_edi_einvoice = json_data['description']['Id']
                            account_move.l10n_xma_uuid_invoice = json_data['description']['numCDC']
                            
                        if json_data['description']['type'] == 'NRP':
                            stock_picking = env_registry['stock.picking'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            # account_move.is_einvoice_send = True
                            # account_move.l10n_xma_edi_einvoice = json_data['description']['Id']
                            cdc = json_data['description']['numCDC']
                            stock_picking.l10n_xma_uuid_invoice = cdc
                            # if cdc:
                            #     stock_picking.consult_invoice_status()
                            # account_move.l10n_xma_uuid_invoice = json_data['description']['NumCDC']
                            
                        
                        if json_data['description']['type'] == 'D':
                            stock_picking = env_registry['stock.picking'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            stock_picking.edi_cadena_original = json_data['description']['cadenaOriginal']
                            cadenaoriginalsp = json_data['description']['cadenaOriginal'].split('|')[3]
                            stock_picking.l10n_sing = True
                            stock_picking.l10n_xma_electronic_number = cadenaoriginalsp
                            
                        if json_data['description']['type'] == 'P':
                            account_payment = env_registry['account.payment'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            account_payment.l10n_xma_timbre = True
                            account_payment.l10n_xma_cadena_original = json_data['description']['cadenaOriginal']
                            cadenaoriginalsp = json_data['description']['cadenaOriginal'].split('|')[3]
                            account_payment.l10n_xma_uuid_invoice = cadenaoriginalsp
                            datetime_str = json_data['datetime'].replace('T', ' ')
                            date = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
                            account_payment.l10n_xma_post_time = date
                            
                        if json_data['description']['type'] == 'N':
                            nomina = env_registry['hr.payslip'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            # NOTE revisar los campos ha llenar en el modulo de la nomina
                            nomina.l10n_xma_timbre = True
                            nomina.l10n_xma_cadena_original = json_data['description']['cadenaOriginal']
                            cadenaoriginalsp = json_data['description']['cadenaOriginal'].split('|')[3]
                            nomina.l10n_xma_uuid_invoice = cadenaoriginalsp
                            datetime_str = json_data['datetime'].replace('T', ' ')
                            date = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
                            # nomina.l10n_xma_post_time = date
                            
                except Exception as err:
                    payload = [{"message": str(err)}]
                    self.client.send_message_serialized(payload, self.STAMPED, error=True, valid_json=True)

        @client.endpoint(prefix + self.FAILED, force_json=True, secure=True)
        def failed(client: Client, __, json_data: Union[List[dict], dict]):
            print(f"DATA ||||||||||||||||||||||||||||||||\n {json_data}")
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                try:
                    json_data = json_data[0]
                    country = json_data['country']
                    rfc = ''
                    if country == 'do':
                        rfc = json_data['rfc'].split('-')[0]
                    if country == 'py':
                        rfc = json_data['rfc'].split('-')[0]
                        rfc = rfc.lstrip('0')
                    if country == 'mx':
                        rfc = json_data['rfc']
                    if country == 'gt':
                        rfc = json_data['rfc']
                    if country == "br":
                        rfc = "{}{}.{}{}{}.{}{}{}/{}{}{}{}-{}{}".format(*json_data['rfc'])
                    comp = env_registry['res.company'].sudo().search([
                        ('vat', '=', rfc)
                    ], limit=1)
                    msg = "Failed: -------------------------------" + str(comp.vat)
                    if comp:
                        
                        ### SECCION GUATEMALA
                        if json_data['description']['type'] == 'FGT':
                            if json_data['description']['payment'] == True:
                                acp = env_registry['account.payment'].sudo().search([
                                    ('id', '=', json_data['id'])
                                ], limit=1)
                                lerrores = ""
                                for x in json_data['description']['response']['errores']:
                                    lerrores += "<li>%s</li>" % x['mensaje_error']
                                mbody = """<p>Respuesta SAT:</p><ul><li><strong>%s</strong></li>%s</ul>""" % (json_data['description']['response']['descripcion'], lerrores)
                                    
                                acp.message_post(body=mbody, body_is_html=True, message_type='comment')
                                acp.l10n_xma_einvoice_status='failed'
                            if json_data['description']['payment'] == False:
                                acc = env_registry['account.move'].sudo().search([
                                    ('id', '=', json_data['id'])
                                ], limit=1)
                                # acc.message_post(
                                #     body=_(
                                #         """<p>El servicio de firma SAT-GT falló. </p><p>%s</p>""" % json_data['description']['response']['descripcion']))
                                lerrores = ""
                                for x in json_data['description']['response']['errores']:
                                    lerrores += "<li>%s</li>" % x['mensaje_error']
                                mbody = """<p>Respuesta SAT:</p><ul><li><strong>%s</strong></li>%s</ul>""" % (json_data['description']['response']['descripcion'], lerrores)
                                    
                                acc.message_post(body=mbody, body_is_html=True, message_type='comment')
                                acc.l10n_xma_einvoice_status='failed'
                                # with registry(env.cr.dbname).cursor() as crn:
                                #     env(cr=crn)["account.move"].sudo().browse([json_data['id']]).write({'l10n_xma_uuid_invoice': cdc})
                                env_registry['xma.sequence.log'].sudo().create({
                                        'move_id': acc.id,
                                        'error_log': """%s""" % (json_data['description']['response']),
                                        'no_document': "%s" % acc.sequence_number,
                                        'date': datetime.now().date(),
                                        'document_type_id': acc.l10n_xma_document_type.id,
                                        'company_id': acc.company_id.id,

                                    })
                        ### SECCION GUATEMALA
                        
                        if json_data['description']['type'] == 'BF':
                            acc = env_registry['account.move'].sudo().search([
                                    ('id', '=', json_data['id'])
                                ], limit=1)
                            acc.message_post(
                                body=_(
                                    """<p>El servicio de firma solicitado falló. </p><p><ul>%s</ul></p>""" %
                                    json_data['description']['response']))
                            
                            env_registry['xma.sequence.log'].sudo().create({
                                    'move_id': acc.id,
                                    'error_log': """%s""" % (json_data['description']['response']),
                                    'no_document': "%s" % acc.xma_l10n_latam_document_number or acc.l10n_latam_document_number or acc.sequence_number,
                                    'date': datetime.now().date(),
                                    'document_type_id': acc.l10n_xma_document_type.id,
                                    'company_id': acc.company_id.id

                                })
                        if json_data['description']['type'] == 'DF':
                            acc = env_registry['account.move'].search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            acc.message_post(
                                body=_(
                                    "Error: %s" % json_data['description']['response']),
                                body_is_html=True,
                                message_type='notification', # Cambiado de 'comment' a 'notification'
                                subtype_xmlid='mail.mt_note'  # Esta es la clave para que sea nota interna
                            )
                            if json_data['description']['response']['status_code'] == 400:
                                if json_data['description']['response']['tipo_ecf'] != 32:
                                    acc.message_post(
                                        body=_(
                                            """<p>El servicio de firma solicitado falló. </p><p><ul>%s: %s </ul></p>""" %
                                            (json_data['description']['response']['error'], json_data['description']['response']['mensaje'])),
                                        body_is_html=True,
                                        message_type='notification',
                                        subtype_xmlid='mail.mt_note'
                                    )
                                
                                    seq_consume = acc.l10n_latam_document_type_id.l10n_xma_current_number-1
                                    acc.message_post(
                                        body=_(
                                            "Secuencia %s Consumida" % seq_consume),
                                        body_is_html=True,
                                        message_type='notification',
                                        subtype_xmlid='mail.mt_note'
                                    )
                                
                                    acc.generate_name_XML_do()
                                    acc.l10n_latam_document_type_id.consume_sequence()
                                else:
                                    mensajes = ""
                                    for x in json_data['description']['response']['mensajes']:
                                        mensajes += "<li>Codigo: %s (%s)</li>" % (x['codigo'], x['valor'])
                                    secutil = "No" if json_data['description']['response']['secuenciaUtilizada'] == False else "Si"
                                    acc.message_post(
                                        body=_(
                                            """<p>El servicio de firma solicitado falló. </p><p><ul><li>Estado: %s</li><li>ENCF: %s</li><li>Sec. Utilizada: %s</li>%s</ul></p>""" %
                                            (json_data['description']['response']['estado'], json_data['description']['response']['encf'], secutil, mensajes)),
                                        body_is_html=True,
                                        message_type='notification',
                                        subtype_xmlid='mail.mt_note'
                                    )
                                    seq_consume = acc.l10n_latam_document_type_id.l10n_xma_current_number-1
                                    acc.message_post(
                                        body=_(
                                            "Secuencia %s Consumida" % seq_consume),
                                        body_is_html=True,
                                        message_type='notification',
                                        subtype_xmlid='mail.mt_note'
                                    )
                                    acc.generate_name_XML_do()
                                    acc.l10n_latam_document_type_id.consume_sequence()
                        if json_data['description']['type'] == 'FD':
                            acc = env_registry['account.move'].search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            acc.message_post(
                                body=_(
                                    """<p>El servicio de firma solicitado falló. </p><p><ul>%s</ul></p>""" %
                                    json_data['description']['response']))
                            
                        if json_data['description']['type'] == 'F':
                            acc = env_registry['account.move'].search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            acc.message_post(
                                body=_(
                                    """<p>El servicio de firma solicitado falló. </p><p><ul>%s</ul></p>""" %
                                    json_data['description']['response']))
                            if json_data['description']['uuid'] != '' and json_data['description']['uuid'] != None:
                                uuid = json_data['description']['uuid']
                                acc.l10n_xma_uuid_invoice = uuid
                                acc.l10n_xma_consulted_xml(uuid, acc.id, acc.company_id.vat, acc)
                            
                        if json_data['description']['type'] == 'D':
                            stock_picking = env_registry['stock.picking'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            stock_picking.message_post(
                                body=_(
                                    """<p>El servicio de firma solicitado falló. </p><p><ul>%s</ul></p>""" %
                                    json_data['description']['response']))
                            uuid = json_data['description']['uuid']
                            if json_data['description']['uuid'] != '' and json_data['description']['uuid'] != None:
                                stock_picking.l10n_xma_uuid_invoice = uuid
                                stock_picking.l10n_xma_consulted_xml(uuid, stock_picking.id, stock_picking.company_id.vat, stock_picking)
                            
                        if json_data['description']['type'] == 'P':
                            account_payment = env_registry['account.payment'].search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            account_payment.message_post(
                                body=_(
                                    """<p>El servicio de firma solicitado falló. </p><p><ul>%s</ul></p>""" %
                                    json_data['description']['response']))
                            uuid = json_data['description']['uuid']
                            if json_data['description']['uuid'] != '' and json_data['description']['uuid'] != None:
                                account_payment.l10n_xma_uuid_invoice = uuid
                                account_payment.l10n_xma_consulted_xml(uuid, account_payment.id, account_payment.company_id.vat, account_payment)
                            
                        if json_data['description']['type'] == 'N':
                            nomina = env_registry['hr.payslip'].search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            nomina.message_post(
                                body=_(
                                    """<p>El servicio de firma solicitado falló. </p><p><ul>%s</ul></p>""" %
                                    json_data['description']['response']))
                            uuid = json_data['description']['uuid']
                            if json_data['description']['uuid'] != '' and json_data['description']['uuid'] != None:
                                nomina.l10n_xma_uuid_invoice = uuid
                                nomina.l10n_xma_consulted_xml(uuid, nomina.id, nomina.company_id.vat, nomina)
                            
                        if json_data['description']['type'] == 'PF':
                            account_move = env_registry['account.move'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            error = json_data['description']['response']
                            cdc = json_data['description']['response']['numCDC']
                            account_move.l10n_xma_uuid_invoice = cdc
                            if not cdc and error:
                                account_move.message_post(
                                    body=_(
                                        """El servicio de firma solicitado falló. \n %s \n
                                            Numero de CDC para consulta: %s \n
                                        """ % (error['descRetornoInvoiCy'].replace('invoicy', 'xmarts'), cdc) ),
                                    body_is_html=True,
                                    message_type='notification',
                                    subtype_xmlid='mail.mt_note')
                            # else:
                            #     account_move.consult_invoice_statur()
                            
                        if json_data['description']['type'] == 'NRP':
                            stock_picking = env_registry['stock.picking'].sudo().search([
                                ('id', '=', json_data['id'])
                            ], limit=1)
                            print('stock_pickingstock_pickingstock_picking', json_data)
                            cdc = json_data['description']['response']['numCDC']
                            stock_picking.l10n_xma_uuid_invoice = cdc
                            err = json_data['description']['response']['descRetornoInvoiCy']
                            if not cdc and err:
                                stock_picking.message_post(
                                    body=_(
                                        """<p>El servicio de firma solicitado falló. </p><p><ul>%s</ul></p>""" %
                                        err),
                                    body_is_html=True,
                                    message_type='notification',
                                    subtype_xmlid='mail.mt_note')
                            else:
                                stock_picking.consult_invoice_status()
                            

                except Exception as err:
                    payload = {"message": str(err)}
                    traceback.print_exc()
                    self.client.send_message_serialized([payload], self.FAILED, error=True, valid_json=True)

        @client.endpoint(prefix + self.SAVED, force_json=True, secure=True)
        def saved(client: Client, _, json_data: Union[List[dict], dict]):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})

                try:
                    json_data = json_data[0]
                    if company_id.partner_id.vat == json_data['rfc']:
                        certs = env_registry['certificate'].search([], limit=1)
                        certs.sync_status = 'saved'
                        # json_sync = {
                        # "id":certs.id,
                        # "partner_id":company_id.uuid_client,
                        # "company_name":company_id.name,
                        # "country_code":company_id.partner_id.country_id.code,
                        # }
                        # json_sync = json.dumps(json_sync, default=str, separators=(',', ':'), ensure_ascii=False)
                        # json_string = f'#sync {str(json_sync)}'
                        # await bot.api.send_text_message(room.room_id, json_string)
                except Exception as err:
                    payload = {"message": str(err)}
                    self.client.send_message_serialized([payload], self.SAVED, error=True, valid_json=True)

        @client.endpoint(prefix + self.SYNCED, force_json=True, secure=True)
        def synced(client: Client, _, json_data: Union[List[dict], dict]):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})

                try:
                    json_data = json_data[0]
                    if company_id.partner_id.vat == json_data['rfc']:
                        certs = env_registry['certificate'].search([], limit=1)
                        if certs:
                            certs.sync_status = 'sync'
                except Exception as err:
                    payload = {"message": str(err)}
                    self.client.send_message_serialized([payload], self.SYNCED, error=True, valid_json=True)
        @client.endpoint(prefix + self.SOLICITUD_RESPONSE, force_json=True, secure=True)
        def solicitud_response(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                
                json_data = json_data[0]
                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', json_data['rfc'])
                ], limit=1)
                
                if comp:
                    id_registro= int(json_data['id'])
                    import_register = env_registry['xml.import.invoice'].sudo().search([
                        ('id', '=', id_registro)
                    ], limit=1)

                    import_register.write({
                        'id_sat_package': json_data['description']['id_solicitud']
                    })
                    msg = "Su petición de descarga con número %s del proceso fue enviada al servicio de descarga del SAT, la respuesta puede demorar hasta 72 horas dependiendo del tiempo de procesamiento del SAT" % (json_data['description']['id_solicitud'])
                    import_register.message_post(
                        body = (msg),)
        
        @client.endpoint(prefix + self.CHECK_STATUS_RESPONSE, force_json=True, secure=True)
        def check_status_response(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                
                json_data = json_data[0]
                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', json_data['rfc'])
                ], limit=1)
                
                if comp:
                    id_registro= int(json_data['id'])
                    import_register = env_registry['xml.import.invoice'].sudo().search([
                        ('id', '=', id_registro)
                    ], limit=1)
                    code = ''
                    if 'estado_solicitud' in  json_data['description']['response']:
                        code = json_data['description']['response'].get('estado_solicitud', False)

                    import_register.download_sat_status = str(code)
                    if str(code) == '0':
                        import_register.message_post(
                            body = ("Solicitud nueva, en espera de ser procesada por el SAT"),
                        )
                    if str(code) == '1':
                        import_register.message_post(
                            body = ("Solicitud aceptada, en espera de ser procesada por el SAT"),
                        )
                    if str(code) == '2':
                        import_register.message_post(
                            body = ("Solicitud en proceso, el SAT está trabajando en su solicitud"),
                        )
                    if str(code) == '3':
                        import_register.message_post(
                            body = ("Solicitud terminada, los archivos están listos"),
                        )   
                    if str(code) == '4':
                        import_register.message_post(
                            body = ("Solicitud con error, intente nuevamente"),
                        )
                    if str(code) == '6':
                        import_register.message_post(
                            body = ("Solicitud vencida, intente nuevamente"),
                        )
                    if str(code) == '5':
                        import_register.message_post(
                            body = ("Solicitud rechazada"),
                        )
                    
                    if not code and json_data['description'].get('response_code'):
                        import_register.message_post(
                            body = ("Límite de descargas del SAT alcanzado. Los paquetes ya fueron descargados el máximo de veces permitido (2)"),
                        )
        
        @client.endpoint(prefix + self.FILE_SAT, is_file=True, secure=True)
        def file_sat(client: Client, _, json_data):
            dbname = odoo.tools.config['db_name']
            registry = Registry(dbname)
            with registry.cursor() as cr:
                env_registry = odoo.api.Environment(cr, odoo.SUPERUSER_ID, {})
                filename = str(json_data['filename'])
                filename = filename.split('.')[0]
                rfc = filename.split('_')[0]
                file64 = base64.b64encode(json_data['bytes'])

                comp = env_registry['res.company'].sudo().search([
                    ('vat', '=', rfc)
                ], limit=1)

                if comp:
                    id_registro = int(filename.split('_')[1])
                    import_register = env_registry['xml.import.invoice'].sudo().search([
                        ('id', '=', id_registro)
                    ], limit=1)
                    # Validate file size
                    file_size_kb = len(json_data['bytes']) / 1024
                    if file_size_kb > 100:
                        import_register.file_char = file64
                        import_register.file_base64 = file64
                        import_register.file_base64_name = str(import_register.name) + '.zip'
            
        @client.endpoint(prefix + self.TIMEOUT_CLIENT, force_json=True, secure=True) 
        def timeout_client(client: Client, _, json_data: Union[List[dict], dict]): 
            client.disconnect() 

    def _send_serialized_messages(self, command_name: str, data: Union[list[dict], str],
                                  route, encode=False, valid_json=False, error=False, message_id=0, secure=True):
        self.client.send_message_serialized(data, route, valid_json=valid_json, error=error, secure=secure)
